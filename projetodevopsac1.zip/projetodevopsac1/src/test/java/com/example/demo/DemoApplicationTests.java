package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.facens.model.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class DemoApplicationTests {

	@Test
	void TesteSeAlunoTemNome()
	{
		Aluno a = new Aluno();
		
		assertEquals(a.getNome(), "");
		
		a.setNome("joao");
		assertEquals(a.getNome(), "joao");
		
	}

}
