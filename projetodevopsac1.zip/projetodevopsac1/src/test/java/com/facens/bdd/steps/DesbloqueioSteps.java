package com.facens.bdd.steps;

import static org.junit.jupiter.api.Assertions.*;

import com.facens.model.Aluno;
import com.facens.model.Curso;
import com.facens.service.CursoService;
import com.facens.service.impl.CursoServiceImpl;
import com.facens.service.impl.CursoServiceStub;
import io.cucumber.java.pt.*;

public class DesbloqueioSteps {

    // ----- Arrange (objetos necessários para todos os cenários)
	private final CursoService service = new CursoServiceImpl();
    private Aluno aluno;
    private Curso curso;
    private boolean result;
    private String mensagem;

    // ===== Integrante 1 =====
    @Dado("que sou um aluno que concluiu todas as atividades de um curso")
    public void concluiu_todas_atividades() {
        aluno = new Aluno(); // usa sua classe já existente
        curso = new Curso("C1");
        assertTrue(service.concluiuTodasAtividades(aluno, curso), "Pré-condição falhou no stub");
    }

    @Quando("minha nota final for igual ou superior a {double}")
    public void nota_igual_ou_superior(double nota) {
        double media = service.obterMediaFinal(aluno, curso);
        assertTrue(media >= nota, "Média retornada pelo stub deveria ser >= " + nota);
    }

    @Entao("devo desbloquear novos cursos para continuar minha evolução")
    public void desbloquear_novos_cursos() {
        // ----- Action
        result = service.desbloquearProximosCursos(aluno);
        // ----- Assert (esperado TRUE, stub devolve FALSE -> falha)
        assertTrue(result, "Esperado TRUE (desbloquear), obtido FALSE do stub.");
    }

    @E("a conquista deve ser registrada no meu perfil na plataforma")
    public void conquista_registrada() {
        // ----- Action
        service.registrarConquista(aluno, "Desbloqueio alcançado");
        // ----- Assert (placeholder — validaremos de fato quando houver implementação)
        assertTrue(true);
    }

    // ===== Integrante 2 =====
    @Dado("que sou um aluno assinante")
    public void aluno_assinante() {
        aluno = new Aluno();
        curso = new Curso("C2");
        // se a sua classe Aluno tiver flag de assinatura, ajuste aqui
        assertNotNull(aluno);
    }

    @Quando("eu escolher e me matricular em um curso")
    public void escolher_matricular() {
        // ----- Action
        service.matricular(aluno, curso);
        // ----- Assert
        assertNotNull(curso);
    }

    @Entao("devo ser notificado que preciso iniciar os estudos em até {int} dias")
    public void notificar_inicio_em_ate(Integer dias) {
        // ----- Action
        result = service.deveNotificarInicioEm7Dias(aluno, curso);
        // ----- Assert (esperado TRUE; stub devolve FALSE -> falha)
        assertTrue(result, "Esperado notificar em " + dias + " dias = TRUE.");
    }

    @E("devo concluir o curso em no máximo {int} ano")
    public void concluir_em_um_ano(Integer anos) {
        // ----- Action
        result = service.deveConcluirEmAte1Ano(aluno, curso);
        // ----- Assert (esperado TRUE; stub devolve FALSE -> falha)
        assertTrue(result, "Esperado concluir em até " + anos + " ano(s) = TRUE.");
    }

    // ===== Integrante 3 =====
    @Dado("que sou um aluno autenticado na plataforma como assinante ativo")
    public void autenticado_assinante_ativo() {
        aluno = new Aluno();
        assertNotNull(aluno);
    }

    @E("já concluí um curso com média abaixo de {double}")
    public void media_abaixo_de(double nota) {
        // Pré-condição simulada (stub não usa, mas documenta a intenção)
        assertTrue(6.9 < nota, "A média de exemplo (6.9) deve ser menor que " + nota);
    }

    @Quando("eu tento acessar novos cursos")
    public void tentar_acessar_novos_cursos() {
        // ação efetiva ocorrerá no Then
    }

    @Entao("o sistema deve bloquear a liberação dos próximos cursos")
    public void bloquear_liberacao() {
        // ----- Action
        result = service.bloquearAcessoProximosCursos(aluno);
        // ----- Assert (esperado TRUE; stub devolve FALSE -> falha)
        assertTrue(result, "Esperado BLOQUEIO = TRUE quando média < 7.0 (stub retornou FALSE).");
    }

    @E("devo receber uma mensagem explicando que preciso melhorar a nota para desbloquear")
    public void receber_mensagem() {
        // ----- Action
        mensagem = service.ultimaMensagemAoAluno(aluno);
        // ----- Assert (esperado mensagem com orientação; stub retorna null -> falha)
        assertNotNull(mensagem, "Esperado mensagem ao aluno (stub retorna null).");
        assertTrue(mensagem != null && mensagem.toLowerCase().contains("melhorar"),
                "Mensagem deveria orientar a melhorar a nota para desbloquear.");
    }
}
