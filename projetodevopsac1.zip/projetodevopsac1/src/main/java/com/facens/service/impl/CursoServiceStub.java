package com.facens.service.impl;

import com.facens.model.Aluno;
import com.facens.model.Curso;
import com.facens.service.CursoService;

public class CursoServiceStub implements CursoService {

    private String ultimaMensagem = null;

    @Override
    public boolean concluiuTodasAtividades(Aluno a, Curso c) {
        return true;
    }

    @Override
    public double obterMediaFinal(Aluno a, Curso c) {
        return 7.0;
    }

    @Override
    public boolean desbloquearProximosCursos(Aluno a) {
        return false; 
    }

    @Override
    public void registrarConquista(Aluno a, String descricao) {
       
    }

    @Override
    public void matricular(Aluno a, Curso c) {
      
    }

    @Override
    public boolean deveNotificarInicioEm7Dias(Aluno a, Curso c) {
        return false; 
    }

    @Override
    public boolean deveConcluirEmAte1Ano(Aluno a, Curso c) {
        return false; 
    }

    @Override
    public boolean bloquearAcessoProximosCursos(Aluno a) {
        return false; // deveria ser true quando média < 7 -> falha
    }

    @Override
    public String ultimaMensagemAoAluno(Aluno a) {
        return ultimaMensagem; 
    }
}
