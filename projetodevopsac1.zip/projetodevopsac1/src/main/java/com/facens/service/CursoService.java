package com.facens.service;

import com.facens.model.Aluno;
import com.facens.model.Curso;

public interface CursoService {
    boolean concluiuTodasAtividades(Aluno aluno, Curso curso);
    double obterMediaFinal(Aluno aluno, Curso curso);

    boolean desbloquearProximosCursos(Aluno aluno);
    void registrarConquista(Aluno aluno, String descricao);

    void matricular(Aluno aluno, Curso curso);
    boolean deveNotificarInicioEm7Dias(Aluno aluno, Curso curso);
    boolean deveConcluirEmAte1Ano(Aluno aluno, Curso curso);

    boolean bloquearAcessoProximosCursos(Aluno aluno);
    String ultimaMensagemAoAluno(Aluno aluno);
}
