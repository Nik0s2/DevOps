package com.facens.model;

public class Aluno {
	private int id;
	private String nome;
	private boolean premium = false;
	
	public Aluno() {
		id = 0;
		nome = "";
	}
	
	public Aluno(int id, String nome) {
		super();
		this.id = id;
		this.nome = nome;
		premium = false;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
