package com.facens.model;

public class Curso {
    private final String id;
    public Curso(String id) { this.id = id; }
    public String getId() { return id; }
}
